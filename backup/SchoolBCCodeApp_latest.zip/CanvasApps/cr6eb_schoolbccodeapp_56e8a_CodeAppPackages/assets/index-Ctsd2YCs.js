import{e}from"./index-BTisP10k.js";import{i as c}from"./index-BTisP10k.js";/*!
 * Copyright (C) Microsoft Corporation. All rights reserved.
 */let t;async function n(){return t||(t=await e("AppLifecycle","getContext"),t)}export{n as getContext,c as initialize};
